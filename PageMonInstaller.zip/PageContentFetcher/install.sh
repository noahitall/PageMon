#!/bin/bash

# PageMon Content Fetcher Installer
# This script installs the PageMon content fetcher to a standard location

set -e

# Set terminal colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓${NC}"
echo -e "${BLUE}┃           PageMon Content Fetcher Installer        ┃${NC}"
echo -e "${BLUE}┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛${NC}"
echo

# Get this script's directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Determine install location
echo -e "${YELLOW}Select installation location:${NC}"
echo "1) User Applications ($HOME/Applications/PageMon) [Recommended]"
echo "2) System Applications (/Applications/PageMon) [Requires admin]"
echo "3) Custom location"
echo
read -p "Enter choice [1-3] (default: 1): " CHOICE

case $CHOICE in
    2)
        INSTALL_DIR="/Applications/PageMon"
        SUDO_REQUIRED=true
        ;;
    3)
        read -p "Enter custom installation path: " CUSTOM_PATH
        INSTALL_DIR="${CUSTOM_PATH}"
        # Check if we need sudo for the custom path
        if [[ "$INSTALL_DIR" == "/usr/"* || "$INSTALL_DIR" == "/opt/"* || "$INSTALL_DIR" == "/Library/"* ]]; then
            SUDO_REQUIRED=true
        fi
        ;;
    *)
        INSTALL_DIR="$HOME/Applications/PageMon"
        SUDO_REQUIRED=false
        ;;
esac

echo
echo -e "Installing to: ${GREEN}$INSTALL_DIR${NC}"

# Create command prefix with sudo if required
CMD_PREFIX=""
if [ "$SUDO_REQUIRED" = true ]; then
    echo "This location requires administrator privileges."
    CMD_PREFIX="sudo"
fi

# Create directories
echo "Creating directories..."
$CMD_PREFIX mkdir -p "$INSTALL_DIR"
$CMD_PREFIX mkdir -p "$INSTALL_DIR/PageContentFetcher"

# Copy files
echo "Copying files..."
$CMD_PREFIX cp -r "$SCRIPT_DIR"/*.js "$INSTALL_DIR/PageContentFetcher/"
$CMD_PREFIX cp -r "$SCRIPT_DIR"/*.sh "$INSTALL_DIR/PageContentFetcher/"
$CMD_PREFIX cp -r "$SCRIPT_DIR/package.json" "$INSTALL_DIR/PageContentFetcher/"
$CMD_PREFIX cp -r "$SCRIPT_DIR/README.md" "$INSTALL_DIR/PageContentFetcher/"

# Set permissions
echo "Setting permissions..."
$CMD_PREFIX chmod +x "$INSTALL_DIR/PageContentFetcher"/*.js
$CMD_PREFIX chmod +x "$INSTALL_DIR/PageContentFetcher"/*.sh

# Set ownership if necessary
if [ "$SUDO_REQUIRED" = true ]; then
    echo "Setting ownership..."
    sudo chown -R $(whoami) "$INSTALL_DIR"
fi

# Verify and install Node.js dependencies
echo "Checking Node.js environment..."
cd "$INSTALL_DIR/PageContentFetcher"
./install-verify.sh

if [ $? -ne 0 ]; then
    echo -e "${RED}Error during verification. Installation may not be complete.${NC}"
    echo "Please check the logs and try to resolve any issues before using the widget."
    exit 1
fi

echo -e "\n${GREEN}✅ Installation completed successfully!${NC}"
echo
echo "Please update your PageWidget configuration to use this path:"
echo -e "${BLUE}$INSTALL_DIR/PageContentFetcher/index.js${NC}"
echo
echo "Instructions for updating your widget:"
echo "1. Open your Xcode project"
echo "2. Edit PageWidget.swift"
echo "3. Make sure this path is included in the possibleScriptDirs array:"
echo "   \"$INSTALL_DIR/PageContentFetcher\""
echo
echo -e "${GREEN}Thank you for using PageMon!${NC}"

exit 0 