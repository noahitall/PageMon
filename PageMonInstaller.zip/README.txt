PageMon Content Fetcher Installer

This package contains the PageMon content fetcher, which is required
for the PageMon widget to extract content from websites.

Installation Instructions:
1. Extract the ZIP file
2. Open Terminal
3. Navigate to the extracted PageContentFetcher directory
4. Run ./install.sh
5. Follow the prompts in the installer
6. Update your widget code to use the installed path

Requirements:
- macOS 10.15 or later
- Node.js 14 or later

After installation, you will need to update your widget code to use the
installed content fetcher path. The installer will show you the path to use.

Support:
If you encounter any issues, please check the troubleshooting section
in the PageContentFetcher/README.md file.
